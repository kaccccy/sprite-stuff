
public class CollidingSpriteMain {
	
	public static void main(String[] args)
	{
		CollidingSpriteAnimation animation = new CollidingSpriteAnimation();
		AnimationFrame frame = new AnimationFrame((Animation)animation);
		frame.start();
	}

}
