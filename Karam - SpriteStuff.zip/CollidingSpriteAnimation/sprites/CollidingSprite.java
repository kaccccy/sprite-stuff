
public interface CollidingSprite {

	public long getScore();
	
	public String getProximityMessage();
	
	public boolean getIsAtExit();

}
